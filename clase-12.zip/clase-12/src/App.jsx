import TecnicaUno from "./componentes/TecnicaUno/TecnicaUno"
import TecnicaDos from "./componentes/TecnicaDos/TecnicaDos"
import TecnicaTres from "./componentes/TecnicaTres/TecnicaTres"
import EstilosCondicionales from "./componentes/EstilosCondicionales/EstilosCondicionales"
import BotonCondicional from "./componentes/BotonCondicional/BotonCondicional"

const App = () => {
  return (
    <div>
      <h1>Bienvenidos a la clase 12</h1>
      <TecnicaUno nombre="Tinki Winki" />
      <TecnicaDos booleano/>
      <TecnicaTres booleano={false}/>
      <EstilosCondicionales booleano={false} clase={"nuevaClase"}/>
      <BotonCondicional/>
    </div>
  )
}


export default App