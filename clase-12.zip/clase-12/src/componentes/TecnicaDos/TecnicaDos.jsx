//2) En línea con Fragment. 

//La usamos cuando deseamos renderizar un elemento condicional en función de una expresión booleana. 

const TecnicaDos = ({booleano}) => {
  return (
    <>
        {booleano && <h2>Usuario Autorizado</h2>}
        {!booleano && <h2>Usuario No Autorizado</h2>}

    </>
    //Recibo un booleano, si el booleano es true, voy a renderizar el elemento. 
    //! = niega el valor. 
  )
}

export default TecnicaDos