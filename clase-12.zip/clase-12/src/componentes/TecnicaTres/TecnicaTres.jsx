//3) OPERADOR TERNARIO: 

//CONDICION ? CODIGO SI ES VERDAD : CODIGO SI ES FALSO

const TecnicaTres = ({booleano}) => {
  return (
    <div>
        {
          booleano ? <h3>Acceso Permitido </h3> : <h3> Acceso Denegado</h3>
        }

    </div>
  )
}

export default TecnicaTres